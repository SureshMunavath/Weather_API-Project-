import {useState} from "react"
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Weatherbox from "./Weatherbox";
import "./Search_box.css"
export default function Search_box({updateinfo})
{
   
    let [city,setCity]=useState("");
    let [error,setError]=useState(false);
    let url="https://api.openweathermap.org/data/2.5/weather";
    let api_key="c86bd4cda26ccb3dd04f8379ef16ea6a";
    let  getinfo=async ()=>
    {
        try{
        let response=await fetch(`${url}?q=${city}&appid=${api_key}&units=metric`);
    
        let info=await response.json();
        console.log(info);
        let weatherinfo={city:city,temp:info.main.temp,
            tempmin:info.main.temp_min,
            tempmax:info.main.temp_max,
            humidity:info.main.humidity,
            feelsLike:info.main.feels_like,
            Pressure:info.main.pressure,};
            console.log(weatherinfo);
            return weatherinfo;
   }
   catch(err)
   {
    throw (err);
   }
}
    let handlechange=(evnt)=>
    {
       setCity(evnt.target.value);
    };
    
        let look=async(evnt)=>
        {
            try{
            evnt.preventDefault();
            console.log(city);
            let newinfo=await getinfo();
            updateinfo(newinfo);
            }
            catch
            {
                setError(true);
            }
        };
    

    return (<>
    <div className="Search_box">
    <form onSubmit={look}>
    <TextField id="outlined-basic" label="City" variant="outlined" onChange={handlechange}/>
    <br/>
    {error && <p>"Enter valid city name</p>}
    <br/>
    <Button variant="contained" type="submit" onClick={()=>{setError(false)}}>Get Report</Button>
    <br/>
    <br/> 
    </form>
    </div>
    </>)
}