import * as React from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import { CardActionArea } from '@mui/material';
import "./Weatherbox.css"

export default function Weatherbox({info}) {
  //let photo="https://images.unsplash.com/photo-1504608524841-42fe6f032b4b?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTJ8fFdlYXRoZXJ8ZW58MHx8MHx8fDA%3";
  let Hot_url="https://media.istockphoto.com/id/1254065595/photo/hot-summer-or-heat-wave-background.webp?s=1024x1024&w=is&k=20&c=FaZwWyck7yOcZQGFIFUsChGv532Wh8eN9nrk5tMyCkg=";
  let Cold_url="https://images.unsplash.com/photo-1621124266180-727515a3974a?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTl8fGNvbGQlMjB3ZWF0aGVyfGVufDB8fDB8fHww"
  let Rainy="https://media.istockphoto.com/id/1407348197/photo/water-drops-on-the-glass-concept-of-driving-in-rain-bad-driving-conditions-selective-focus.webp?b=1&s=170667a&w=0&k=20&c=GYLG2EfRG1iyFti-KtyXsNLxfHG_1hKLr6-gF6iG-UA="
  return (
    <div className="Weatherbox">
      <Card sx={{ maxWidth: 345}}>
      <CardActionArea>
        <CardMedia
          component="img"
          height="300"
          image={info.humidity>80?Rainy:(info.temp>15?Hot_url:Cold_url)}
          alt="green iguana"
        />
        <CardContent>
          <Typography gutterBottom variant="h5" component="div">
            City: {info.city}
          </Typography>
          <Typography variant="body2" color="text.secondary" component={"span"}>
          <span><p>Temperature:{info.temp}&deg;C</p>{info.humidity>80?<i class="fa-solid fa-temperature-low"></i>:(info.temp>15?<i class="fa-solid fa-sun"></i>:<i class="fa-solid fa-sun"></i>)}</span>
          <p>Temp-min:&nbsp;{info.tempmin}&deg;C</p>
          <p>Temp-max:&nbsp;{info.tempmax}&deg;C</p>
          <p>Humidity:&nbsp;{info.humidity}</p>
          <p>Feels like:&nbsp;{info.feelsLike}</p>
          <p>Pressure:&nbsp;{info.Pressure}</p>
          </Typography>
        </CardContent>
      </CardActionArea>
    </Card>
    </div>
  );
}