import {useState} from 'react';
import Search_box from "./Search_box";
import Weatherbox from "./Weatherbox";
//import "./WeatherApp.css"

export default function WeatherApp()
{
    let [weatherinfo,setWeatherinfo]=useState({city:"",temp:"",tempmin:"",tempmax:"",humidity:"",feelsLike:"",Pressure:""});

    let updateinfo=(result)=>
    {
        setWeatherinfo(result);
    }
    return (
        <div className="WeatherApp">
            <h3 style={{color:"-moz-initial"}}>WEATHER-REPORT</h3>
            <br/>
            <Search_box updateinfo={updateinfo}/>
            <br/>
            <Weatherbox info={weatherinfo}/>
        </div>
    )
}